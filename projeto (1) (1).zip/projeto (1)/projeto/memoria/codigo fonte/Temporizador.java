/* **
 * Faculdade de Engenharias Arquitetura e Urbanismo (FEAU) - (Univap)
 * Curso: Engenharia da Computação - Data de Entrega: 21/06/2022
 * Autores: Pedro Rodrigues Santos Valle  - 01810422
 *    
 * Turma: 9UNA Disciplina: Algoritmos Estrutura de Dados - II
 * Projeto de Avaliação parcial referente ao 2 - Bimestre
 * Observação: o projeto pode ser executado a partir desta classe.
 * projeto.java
 *
 * ***/
package memoria;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pedro
 */
public class Temporizador implements ActionListener {

    int status = 0;

    @Override
    public void actionPerformed(ActionEvent e) {

    }

    public int mudaStatus() {
        return 3;
    }

}
