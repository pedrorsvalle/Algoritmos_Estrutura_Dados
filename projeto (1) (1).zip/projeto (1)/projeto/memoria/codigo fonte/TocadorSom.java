/* **
 * Faculdade de Engenharias Arquitetura e Urbanismo (FEAU) - (Univap)
 * Curso: Engenharia da Computação - Data de Entrega: 21/06/2022
 * Autores: Pedro Rodrigues Santos Valle  - 01810422
 *    
 * Turma: 9UNA Disciplina: Algoritmos Estrutura de Dados - II
 * Projeto de Avaliação parcial referente ao 2 - Bimestre
 * Observação: o projeto pode ser executado a partir desta classe.
 * projeto.java
 *
 * ***/
package memoria;

import java.io.File;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

/**
 *
 * @author pedro
 */
public class TocadorSom {

   String path;

   public void tocaSom(String strCaractere) {

      try {
         Clip clip = AudioSystem.getClip();
         clip.open(AudioSystem.getAudioInputStream(new File(strCaractere)));
         clip.start();

      } catch (Exception exc) {
         exc.printStackTrace(System.out);
      }

   }
}
