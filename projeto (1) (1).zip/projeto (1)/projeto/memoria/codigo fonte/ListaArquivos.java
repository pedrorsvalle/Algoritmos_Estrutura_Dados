/* **
 * Faculdade de Engenharias Arquitetura e Urbanismo (FEAU) - (Univap)
 * Curso: Engenharia da Computação - Data de Entrega: 21/06/2022
 * Autores: Pedro Rodrigues Santos Valle  - 01810422
 *    
 * Turma: 9UNA Disciplina: Algoritmos Estrutura de Dados - II
 * Projeto de Avaliação parcial referente ao 2 - Bimestre
 * Observação: o projeto pode ser executado a partir desta classe.
 * projeto.java
 *
 * ***/

package memoria;

import java.io.File;
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * 
 */
public class ListaArquivos {

    public ArrayList<String> listagemArquivo(String caminho) {

        try {
            File diretorio = new File(caminho);
            File fileList[] = diretorio.listFiles();

            ArrayList<String> arquivosListado = new ArrayList<String>();

            for (int i = 0; i < fileList.length; i++) {
                arquivosListado.add(fileList[i].getAbsolutePath());
                // System.out.println(arquivosListado.get(i));
            }

            return arquivosListado;

        } catch (Exception ex) {
            return null;
        }

    }

}
