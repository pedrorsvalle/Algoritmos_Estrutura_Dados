/* **
 * Faculdade de Engenharias Arquitetura e Urbanismo (FEAU) - (Univap)
 * Curso: Engenharia da Computação - Data de Entrega: 21/06/2022
 * Autores: Pedro Rodrigues Santos Valle  - 01810422
 *    
 * Turma: 9UNA Disciplina: Algoritmos Estrutura de Dados - II
 * Projeto de Avaliação parcial referente ao 2 - Bimestre
 * Observação: o projeto pode ser executado a partir desta classe.
 * projeto.java
 *
 * ***/
package memoria;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class menuMemoria extends javax.swing.JFrame {

    public menuMemoria() {
        initComponents();

        this.setResizable(false);

        this.setLocationRelativeTo(null);

    }

    @SuppressWarnings("unchecked")

    private void initComponents() {

        grupoLevel = new javax.swing.ButtonGroup();
        grupoquantia = new javax.swing.ButtonGroup();
        radioMuitoFacil = new javax.swing.JRadioButton();
        radioFacil = new javax.swing.JRadioButton();
        radioMedio = new javax.swing.JRadioButton();
        radioDificil = new javax.swing.JRadioButton();
        radioMuitoDificil = new javax.swing.JRadioButton();
        labelLevel = new javax.swing.JLabel();
        labelLevel1 = new javax.swing.JLabel();
        radioQuantia16 = new javax.swing.JRadioButton();
        radioQuantia20 = new javax.swing.JRadioButton();
        radioQuantia24 = new javax.swing.JRadioButton();
        radioQuantia36 = new javax.swing.JRadioButton();
        botaoAvancar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Jogo da Memória Java");
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/memoria/imagemicone/icone.png")).getImage());

        grupoLevel.add(radioMuitoFacil);
        radioMuitoFacil.setSelected(true);
        radioMuitoFacil.setText("Muito Fácil");

        grupoLevel.add(radioFacil);
        radioFacil.setText("Fácil");

        grupoLevel.add(radioMedio);
        radioMedio.setText("Médio");

        grupoLevel.add(radioDificil);
        radioDificil.setText("Dificil");

        grupoLevel.add(radioMuitoDificil);
        radioMuitoDificil.setText("Muito Dificil");

        labelLevel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        labelLevel.setForeground(new java.awt.Color(255, 0, 0));
        labelLevel.setText("Escolha o Level");

        labelLevel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        labelLevel1.setForeground(new java.awt.Color(255, 0, 0));
        labelLevel1.setText("Escolha Quantos Pares");

        grupoquantia.add(radioQuantia16);
        radioQuantia16.setSelected(true);
        radioQuantia16.setText("9Pares");

        grupoquantia.add(radioQuantia20);
        radioQuantia20.setText("16 Pares");

        grupoquantia.add(radioQuantia24);
        radioQuantia24.setText("25 Pares");

        grupoquantia.add(radioQuantia36);
        radioQuantia36.setText("18 Pares");

        botaoAvancar.setText("Avançar");
        botaoAvancar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoAvancarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(labelLevel, javax.swing.GroupLayout.PREFERRED_SIZE, 129,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(labelLevel1, javax.swing.GroupLayout.PREFERRED_SIZE, 203,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout
                                                        .createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING,
                                                                false)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(radioMuitoFacil)
                                                                .addGap(39, 39, 39)
                                                                .addComponent(radioFacil)
                                                                .addGap(53, 53, 53))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(radioQuantia16)
                                                                .addPreferredGap(
                                                                        javax.swing.LayoutStyle.ComponentPlacement.RELATED,
                                                                        javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                        Short.MAX_VALUE)
                                                                .addComponent(radioQuantia20)
                                                                .addGap(33, 33, 33)))
                                                .addGroup(layout
                                                        .createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(radioMedio)
                                                        .addComponent(radioQuantia24))
                                                .addGap(33, 33, 33)
                                                .addGroup(layout
                                                        .createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(radioQuantia36)
                                                                .addGap(36, 36, 36)
                                                                .addComponent(botaoAvancar,
                                                                        javax.swing.GroupLayout.DEFAULT_SIZE, 133,
                                                                        Short.MAX_VALUE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(radioDificil)
                                                                .addGap(40, 40, 40)
                                                                .addComponent(radioMuitoDificil)))))
                                .addContainerGap()));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(labelLevel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(radioMuitoFacil)
                                        .addComponent(radioFacil)
                                        .addComponent(radioMedio)
                                        .addComponent(radioDificil)
                                        .addComponent(radioMuitoDificil))
                                .addGap(29, 29, 29)
                                .addComponent(labelLevel1)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(radioQuantia16)
                                        .addComponent(radioQuantia20)
                                        .addComponent(radioQuantia24)
                                        .addComponent(radioQuantia36)
                                        .addComponent(botaoAvancar))
                                .addContainerGap(31, Short.MAX_VALUE)));

        pack();
    }

    private void botaoAvancarActionPerformed(java.awt.event.ActionEvent evt) {
        MemoriaJava objMemoriaJava;
        try {
            if (radioMuitoFacil.isSelected() && radioQuantia16.isSelected()) {

                objMemoriaJava = new MemoriaJava(16, 1, "Muito Fácil");

                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMuitoFacil.isSelected() && radioQuantia20.isSelected()) {
                objMemoriaJava = new MemoriaJava(20, 1, "Muito Fácil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMuitoFacil.isSelected() && radioQuantia24.isSelected()) {
                objMemoriaJava = new MemoriaJava(24, 1, "Muito Fácil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMuitoFacil.isSelected() && radioQuantia36.isSelected()) {
                objMemoriaJava = new MemoriaJava(36, 1, "Muito Fácil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioFacil.isSelected() && radioQuantia16.isSelected()) {
                objMemoriaJava = new MemoriaJava(16, 3, "Fácil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioFacil.isSelected() && radioQuantia20.isSelected()) {
                objMemoriaJava = new MemoriaJava(20, 5, "Fácil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioFacil.isSelected() && radioQuantia24.isSelected()) {
                objMemoriaJava = new MemoriaJava(24, 5, "Fácil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioFacil.isSelected() && radioQuantia36.isSelected()) {
                objMemoriaJava = new MemoriaJava(36, 7, "Fácil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMedio.isSelected() && radioQuantia16.isSelected()) {
                objMemoriaJava = new MemoriaJava(16, 5, "Médio");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMedio.isSelected() && radioQuantia20.isSelected()) {
                objMemoriaJava = new MemoriaJava(20, 6, "Médio");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMedio.isSelected() && radioQuantia24.isSelected()) {
                objMemoriaJava = new MemoriaJava(24, 7, "Médio");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMedio.isSelected() && radioQuantia36.isSelected()) {
                objMemoriaJava = new MemoriaJava(36, 11, "Médio");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioDificil.isSelected() && radioQuantia16.isSelected()) {
                objMemoriaJava = new MemoriaJava(16, 8, "Dificil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioDificil.isSelected() && radioQuantia20.isSelected()) {
                objMemoriaJava = new MemoriaJava(20, 10, "Dificil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioDificil.isSelected() && radioQuantia24.isSelected()) {
                objMemoriaJava = new MemoriaJava(24, 12, "Dificil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioDificil.isSelected() && radioQuantia36.isSelected()) {
                objMemoriaJava = new MemoriaJava(36, 18, "Dificil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMuitoDificil.isSelected() && radioQuantia16.isSelected()) {
                objMemoriaJava = new MemoriaJava(16, 13, "Muito Dificil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMuitoDificil.isSelected() && radioQuantia20.isSelected()) {
                objMemoriaJava = new MemoriaJava(20, 16, "Muito Dificil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMuitoDificil.isSelected() && radioQuantia24.isSelected()) {
                objMemoriaJava = new MemoriaJava(24, 20, "Muito Dificil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

            if (radioMuitoDificil.isSelected() && radioQuantia36.isSelected()) {
                objMemoriaJava = new MemoriaJava(36, 29, "Muito Dificil");
                objMemoriaJava.setVisible(true);
                this.hide();
            }

        } catch (Exception ex) {

        }
    }

    /**
     * @param args
     */
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menuMemoria.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menuMemoria.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menuMemoria.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menuMemoria.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new menuMemoria().setVisible(true);
            }
        });
    }

    private javax.swing.JButton botaoAvancar;
    private javax.swing.ButtonGroup grupoLevel;
    private javax.swing.ButtonGroup grupoquantia;
    private javax.swing.JLabel labelLevel;
    private javax.swing.JLabel labelLevel1;
    private javax.swing.JRadioButton radioDificil;
    private javax.swing.JRadioButton radioFacil;
    private javax.swing.JRadioButton radioMedio;
    private javax.swing.JRadioButton radioMuitoDificil;
    private javax.swing.JRadioButton radioMuitoFacil;
    private javax.swing.JRadioButton radioQuantia16;
    private javax.swing.JRadioButton radioQuantia20;
    private javax.swing.JRadioButton radioQuantia24;
    private javax.swing.JRadioButton radioQuantia36;

}
