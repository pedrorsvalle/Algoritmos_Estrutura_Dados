/*
Faculdade de engenharia da computação e Urbanismo(Feau) (Univap)
Curso : Eengenharia da computação - Data de Entrega:30/06/2022
Autor: Pedro Rodrigues Santos Valle
Matricula:01810422

Turma:9UNA Disciplica: Algoritmos Estrutura de Dados - 2
Avaliação parcial referente ao 2 - Bimenestre

*/

package exh;

/**
 *
 * @author pedro
 */
    public class ListaSkip {
 
    private static class SkipNode {
        public SkipNode[] next;
        public int elem;
    
        public SkipNode(int pVal,int pLev){
            elem=pVal;
            next=new SkipNode[pLev];
        }
    
    }
    private final SkipNode head;
    private final int maxLevel;
    private final int actualLevel;
    private int total=0;
    
 
    
    public ListaSkip(int pSeq,int pinicio,int pFim,int pVal, int pMaxLevel){
        
        head= new SkipNode(pVal,pMaxLevel);
        maxLevel=pMaxLevel;
        actualLevel=0;
        total++;
        
    }
}

