/*
Faculdade de engenharia da computação e Urbanismo(Feau) (Univap)
Curso : Eengenharia da computação - Data de Entrega:30/06/2022
Autor: Pedro Rodrigues Santos Valle
Matricula:01810422

Turma:9UNA Disciplica: Algoritmos Estrutura de Dados - 2
Avaliação parcial referente ao 2 - Bimenestre


 */
package exh;

import java.util.Scanner;
/**
 *
 * @author pedro
 */
public class Pro {

    public static void main(String[] args){
        Scanner ent = new Scanner(System.in);
        
        double num, soma = 0;
        int cont = 0;
        
        do{
            System.out.println("Digite um número");
            num = ent.nextDouble(); 
            
            if(num >= 0){ 
                soma = num + soma; 
                cont++; 
            }
        } while(num >= 0); 
        
        System.out.println("A soma é " + soma); 
        System.out.println("A quantidade de números digitados foi " + cont); 
        System.out.println("A média é " + soma / cont); 
    }
}