/*
Faculdade de engenharia da computação e Urbanismo(Feau) (Univap)
Curso : Eengenharia da computação - Data de Entrega:30/06/2022
Autor: Pedro Rodrigues Santos Valle
Matricula:01810422

Turma:9UNA Disciplica: Algoritmos Estrutura de Dados - 2
Avaliação parcial referente ao 2 - Bimenestre


*/
package exh;

/**
 *
 * @author pedro
 */
public class Calculo {
   
    public double fatorial(int n){
	int x = n;
        double fat = 1;
        while (x>1){
            fat = fat * x;
            x--;
        }
        return fat;
    }

    public double combinacao(double fatN, double fatX, double fatNX){
	double comb=0;
	comb=(fatN / (fatX * fatNX));
	return comb;
    }
    
}
